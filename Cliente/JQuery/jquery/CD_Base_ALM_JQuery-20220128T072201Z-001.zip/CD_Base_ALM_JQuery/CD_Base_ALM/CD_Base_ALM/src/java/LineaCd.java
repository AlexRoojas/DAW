/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class LineaCd {
    private String Titulo;
    private String Autor;
    private float Precio;
    private int Cantidad;
    private String Color;

    public LineaCd(String Titulo, String Autor, float Precio, int Cantidad, String Color) {
        this.Titulo = Titulo;
        this.Autor = Autor;
        this.Precio = Precio;
        this.Cantidad = Cantidad;
        this.Color = Color;
    }

   

   
    
    
}
